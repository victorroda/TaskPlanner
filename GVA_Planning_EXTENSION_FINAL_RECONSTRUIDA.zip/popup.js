const PLANNING_URL = "https://victorroda.github.io/TaskPlanner/";

const $ = id => document.getElementById(id);

function setStatus(text,type="") {
  $("status").textContent = text;
  $("status").className = type;
}

function normaliseAssigneeLocal(value) {
  return String(value ?? "").replace(/\s+/g," ").trim() || "Sense assignar";
}

function cleanTextLocal(value) {
  return String(value ?? "").replace(/\s+/g," ").trim();
}

function parseWordsLocal(value) {
  const digits = String(value ?? "").replace(/[^\d]/g,"");
  return digits ? Number(digits) : 0;
}

function extractTasksInPage() {
  const cards = [...document.querySelectorAll(".issue-card[data-id]")];
  const seen = new Set();
  const result = [];

  for (const card of cards) {
    const taskId = cleanTextLocal(card.getAttribute("data-id"));
    if (!taskId || seen.has(taskId)) continue;
    seen.add(taskId);

    const text = cleanTextLocal(card.textContent);

    const nameEl =
      card.querySelector(".subject a") ||
      card.querySelector(".issue-subject a") ||
      card.querySelector(".issue-card-subject a");
    const name = cleanTextLocal(nameEl?.textContent || text.replace(/^.*?#\d+\s*/,""));

    let dueDate = "";
    const dateCandidates = [...card.querySelectorAll("*")];
    for (const el of dateCandidates) {
      const s = cleanTextLocal(el.textContent);
      const m = s.match(/(\d{1,2}\s+[A-Za-zÀ-ÿ]+\s+\d{4})/);
      if (m && /due|venc|data|fecha/i.test(s)) {
        dueDate = m[1];
        break;
      }
    }

    const wordPatterns = [
      /(?:words?|paraules?|palabras?)\s*:?\s*([\d.,]+)/i,
      /([\d.,]+)\s*(?:words?|paraules?|palabras?)/i
    ];
    let words = 0;
    for (const p of wordPatterns) {
      const m = text.match(p);
      if (m) { words = parseWordsLocal(m[1]); break; }
    }

    const userEl = card.querySelector(".assigned-user .user a");
    const assigned = normaliseAssigneeLocal(userEl?.textContent || "");

    result.push({
      taskId,
      name,
      title:name,
      dueDate,
      words,
      assigned,
      url:""
    });
  }
  return result;
}

async function gzipToBase64(text) {
  if (!("CompressionStream" in window)) throw new Error("CompressionStream no està disponible.");
  const cs = new CompressionStream("gzip");
  const compressed = await new Response(
    new Blob([new TextEncoder().encode(text)]).stream().pipeThrough(cs)
  ).arrayBuffer();
  const bytes = new Uint8Array(compressed);
  let binary = "";
  const chunk = 0x8000;
  for (let i=0;i<bytes.length;i+=chunk) {
    binary += String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));
  }
  return btoa(binary);
}

function utf8Base64(text) {
  const bytes = new TextEncoder().encode(text);
  let binary = "";
  const chunk = 0x8000;
  for (let i=0;i<bytes.length;i+=chunk) {
    binary += String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));
  }
  return btoa(binary);
}

async function openPlanning(tasks) {
  const json = JSON.stringify(tasks);
  let payload;
  let mode;
  try {
    payload = await gzipToBase64(json);
    mode = "gzip";
  } catch (e) {
    payload = utf8Base64(json);
    mode = "plain";
  }

  const url = PLANNING_URL + (mode === "gzip" ? "#data-gzip=" : "#data=") +
              encodeURIComponent(payload);

  console.log("[GVA Planning extension] opening", {
    mode, taskCount:tasks.length, payloadChars:payload.length
  });

  await chrome.tabs.create({url});
}

$("extractBtn").addEventListener("click", async () => {
  try {
    setStatus("Comprovant pestanya activa…");
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab?.id || !tab.url?.startsWith("https://gva.i-mes.net/projects/gva/agile/")) {
      throw new Error("La pestanya activa no és el GVA Agile Board.");
    }

    const injected = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:extractTasksInPage
    });

    const extracted = injected?.[0]?.result;
    if (!Array.isArray(extracted)) throw new Error("No s'ha pogut llegir el DOM.");
    if (!extracted.length) throw new Error("No s'han trobat targetes .issue-card[data-id].");

    setStatus(`${extracted.length} tasques trobades. Obrint Planning…`,"ok");
    await openPlanning(extracted);
  } catch (e) {
    console.error(e);
    setStatus("Error: " + e.message,"err");
  }
});
