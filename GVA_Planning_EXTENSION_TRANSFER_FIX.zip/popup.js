// GVA Planning – lector LOCAL del DOM de la pestaña activa.
// IMPORTANTE: no usa fetch(), XMLHttpRequest, WebSocket ni ninguna API del servidor GVA.
// Solo lee el DOM que Chrome ya tiene cargado en la pestaña activa.

const PLANNING_URL = "https://victorroda.github.io/TaskPlanner/";
let tasks = [];

const $ = id => document.getElementById(id);
const statusEl = $("status");

function setStatus(text, type="") {
  statusEl.textContent = text;
  statusEl.className = type;
}

function normaliseAssignee(value) {
  const text = String(value ?? "").replace(/\s+/g, " ").trim();
  if (!text) return "Sin asignar";
  const key = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  if (["sin asignar","sin assignar","no asignada","no asignado","unassigned","none","-","—"].includes(key)) {
    return "Sin asignar";
  }
  return text;
}

function csvEscape(value) {
  return '"' + String(value ?? "").replace(/"/g, '""') + '"';
}

function formatCSVDate(value) {
  if (!value) return "";
  const text = String(value).trim();
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(text)) {
    const [d,m,y] = text.split("/");
    return `${d.padStart(2,"0")}/${m.padStart(2,"0")}/${y}`;
  }
  const months = {
    gen:0, feb:1, mar:2, abr:3, mai:4, jun:5, jul:6, ago:7,
    set:8, oct:9, nov:10, des:11,
    ene:0, dic:11, jan:0, apr:3, may:4, aug:7, sep:8, dec:11
  };
  const match = text.match(/^(\d{1,2})\s+([A-Za-zÀ-ÿ]+)\s+(\d{4})$/);
  if (match) {
    const d = Number(match[1]);
    const m = months[match[2].slice(0,3).toLowerCase()];
    const y = Number(match[3]);
    if (m !== undefined) return `${String(d).padStart(2,"0")}/${String(m+1).padStart(2,"0")}/${y}`;
  }
  return text;
}

function makeCSV() {
  const headers = [
    "Tasca",
    "Nom",
    "Data real de venciment",
    "Nombre de paraules Salt pro",
    "Persona assignada"
  ];
  const lines = [
    headers.map(csvEscape).join(";"),
    ...tasks.map(t => [
      t.taskId,
      t.name || "",
      formatCSVDate(t.dueDate),
      t.words || "",
      t.assigned || ""
    ].map(csvEscape).join(";"))
  ];
  return "\ufeff" + lines.join("\r\n");
}

function downloadCSV() {
  const blob = new Blob([makeCSV()], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "tasques_GVA.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({active:true, currentWindow:true});
  return tabs[0];
}

async function readLocalDOM() {
  setStatus("Leyendo únicamente el DOM ya cargado…");
  try {
    const tab = await getActiveTab();
    if (!tab?.url?.startsWith("https://gva.i-mes.net/projects/gva/agile/")) {
      throw new Error("La pestaña activa no es el Agile Board de GVA.");
    }

    const result = await chrome.scripting.executeScript({
      target: {tabId: tab.id},
      func: () => {
        const clean = v => String(v ?? "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
        const normalLabel = v => clean(v).replace(/[\s:：]+$/g, "").toLowerCase();

        // This function lives INSIDE executeScript because Chrome serializes
        // the function passed to the page and it cannot see popup-scope helpers.
        const normaliseAssigneeLocal = value => {
          const text = clean(value);
          if (!text) return "";
          const key = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
          if (["sin asignar","sin assignar","no asignada","no asignado","unassigned","none","-","—"].includes(key)) {
            return "";
          }
          return text;
        };

        // Convierte números del tipo 22.890, 22,890, 22890, etc.
        function parseWords(value) {
          let s = clean(value).replace(/[^\d.,-]/g, "");
          if (!s) return 0;
          if (s.includes(",") && s.includes(".")) {
            // En este tablero los miles aparecen normalmente como separadores.
            if (s.lastIndexOf(",") > s.lastIndexOf(".")) s = s.replace(/\./g, "").replace(",", ".");
            else s = s.replace(/,/g, "");
          } else if (s.includes(",")) {
            s = s.replace(/,/g, "");
          } else if (s.includes(".") && /^-?\d+\.\d{3}$/.test(s)) {
            s = s.replace(".", "");
          }
          const n = Number(s);
          return Number.isFinite(n) ? n : 0;
        }

        // Extrae el valor situado después de un <b> dentro de .attributes,
        // hasta el siguiente <br>. Esto evita el error anterior que devolvía ':'
        // como fecha/valor porque ':' era el primer text node después del <b>.
        function attributeValue(card, labels) {
          const wanted = new Set(labels.map(normalLabel));
          const attributes = card.querySelector("p.attributes");
          if (!attributes) return "";

          for (const b of attributes.querySelectorAll("b, strong, label")) {
            if (!wanted.has(normalLabel(b.textContent))) continue;

            const parts = [];
            let node = b.nextSibling;
            while (node) {
              if (node.nodeType === Node.ELEMENT_NODE && node.tagName === "BR") break;
              parts.push(node.textContent || "");
              node = node.nextSibling;
            }
            const value = clean(parts.join(" ").replace(/^[\s:：-]+/, ""));
            if (value) return value;

            // Fallback: clona el párrafo y toma el texto posterior al label.
            const parent = b.parentElement;
            if (parent) {
              const clone = parent.cloneNode(true);
              clone.querySelectorAll("b, strong, label").forEach(x => x.remove());
              const fallback = clean(clone.textContent).replace(/^[\s:：-]+/, "");
              if (fallback) return fallback;
            }
          }
          return "";
        }

        function issueId(card) {
          const dataId = card.getAttribute("data-id");
          if (/^\d+$/.test(clean(dataId))) return clean(dataId);

          for (const el of card.querySelectorAll(".issue-id, a[href*='/issues/'], [class*='issue-id']")) {
            const textMatch = clean(el.textContent).match(/#(\d+)/);
            if (textMatch) return textMatch[1];
            const href = el.getAttribute?.("href") || "";
            const hrefMatch = href.match(/\/issues\/(\d+)/);
            if (hrefMatch) return hrefMatch[1];
          }
          const m = clean(card.textContent).match(/#(\d+)/);
          return m ? m[1] : "";
        }

        function getAssigned(card) {
          // Estructura real del GVA exportado:
          // <p class="info assigned-user"><span class="user"><a ...>imes XX</a>
          const selectors = [
            ".assigned-user .user a[href*='/people/']",
            ".assigned-user a[href*='/people/']",
            ".assigned-user .user a",
            "[class*='assigned-user'] a[href*='/people/']",
            "[class*='assigned'] a[href*='/people/']"
          ];
          for (const selector of selectors) {
            const a = card.querySelector(selector);
            const value = clean(a?.textContent);
            if (value) return value;
          }
          return "";
        }

        function getName(card) {
          return clean(card.querySelector("p.name a, p.name")?.textContent) ||
                 clean(card.querySelector(".issue-name, .subject, [class*='subject']")?.textContent);
        }

        // No dependemos de una única variante del selector: usamos todas las tarjetas
        // .issue-card y, si tienen data-id, la usamos como identificador estable.
        const cards = Array.from(document.querySelectorAll(".issue-card"));
        const seen = new Set();
        const out = [];

        for (const card of cards) {
          const taskId = issueId(card);
          if (!taskId || seen.has(taskId)) continue;
          seen.add(taskId);

          const dueDate = attributeValue(card, [
            "Data real de venciment",
            "Fecha real de vencimiento",
            "Real due date",
            "Due date"
          ]);
          const wordsText = attributeValue(card, [
            "Nombre de paraules Salt pro",
            "Número de palabras Salt pro",
            "Salt pro words",
            "Words"
          ]);
          const issueLink = card.querySelector("p.name a[href*='/issues/'], a[href*='/issues/']");

          out.push({
            taskId,
            name: getName(card),
            dueDate,
            words: parseWords(wordsText),
            assigned: normaliseAssigneeLocal(getAssigned(card)),
            url: issueLink?.href || ""
          });
        }

        return {
          tasks: out,
          diagnostics: {
            cards: cards.length,
            unique: out.length,
            withDue: out.filter(t => t.dueDate).length,
            withWords: out.filter(t => t.words > 0).length,
            withAssigned: out.filter(t => t.assigned).length,
            unassigned: out.filter(t => !t.assigned).length
          }
        };
      }
    });

    const payload = result?.[0]?.result;
    tasks = Array.isArray(payload) ? payload : (payload?.tasks || []);
    const d = Array.isArray(payload) ? null : payload?.diagnostics;

    if (!tasks.length) throw new Error("No se encontraron tarjetas de tareas en el DOM cargado.");

    setStatus(
      `✓ ${tasks.length} tareas encontradas · ${d?.withAssigned ?? tasks.filter(t=>t.assigned).length} asignadas · ${d?.unassigned ?? tasks.filter(t=>!t.assigned).length} sin asignar · ${d?.withDue ?? tasks.filter(t=>t.dueDate).length} con fecha. Lectura 100 % local.`,
      "ok"
    );
    $("csv").disabled = false;
    $("open").disabled = false;
  } catch (err) {
    console.error(err);
    setStatus("Error: " + err.message, "err");
  }
}

async function openPlanning() {
  if (!tasks.length) return;

  try {
    const json = JSON.stringify(tasks);
    const bytes = new TextEncoder().encode(json);

    // Compress the payload before putting it in the URL fragment. This is
    // important for large boards (e.g. 88 tasks), where plain base64 can
    // make the URL unnecessarily long.
    if ("CompressionStream" in window) {
      const cs = new CompressionStream("gzip");
      const writer = cs.writable.getWriter();
      writer.write(bytes);
      writer.close();

      const compressed = new Uint8Array(await new Response(cs.readable).arrayBuffer());
      let binary = "";
      const chunk = 0x8000;
      for (let i = 0; i < compressed.length; i += chunk) {
        binary += String.fromCharCode(...compressed.subarray(i, i + chunk));
      }
      const payload = btoa(binary);
      chrome.tabs.create({
        url: PLANNING_URL + "#data-gzip=" + encodeURIComponent(payload)
      });
      return;
    }

    // Fallback for browsers without CompressionStream.
    const payload = btoa(unescape(encodeURIComponent(json)));
    chrome.tabs.create({
      url: PLANNING_URL + "#data=" + encodeURIComponent(payload)
    });
  } catch (err) {
    console.error(err);
    setStatus("Error preparando los datos para GVA Planning.", "err");
  }
}

$("read").addEventListener("click", readLocalDOM);
$("csv").addEventListener("click", downloadCSV);
$("open").addEventListener("click", openPlanning);
