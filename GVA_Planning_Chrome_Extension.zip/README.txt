# GVA Planning – extensión Chrome/Edge

## Seguridad / privacidad

Esta extensión está diseñada para leer exclusivamente el DOM de la pestaña activa.

Permisos:
- `activeTab`: acceso temporal a la pestaña activa cuando el usuario pulsa la extensión.
- `scripting`: permite ejecutar la función lectora en esa pestaña.

No se solicitan permisos de red ni acceso permanente a GVA.

El código de extracción:
- usa `document.querySelectorAll(".issue-card[data-id]")`;
- lee texto y atributos ya cargados;
- no usa `fetch`;
- no usa `XMLHttpRequest`;
- no usa WebSocket;
- no llama a la API de Redmine;
- no envía las tareas a ningún servidor.

## Instalación

1. Abre `popup.js`.
2. Sustituye:
   `https://TU_USUARIO.github.io/gva-planning/`
   por la URL real de tu GitHub Pages.
3. Guarda los archivos.
4. Chrome/Edge -> Extensiones -> activa "Modo desarrollador".
5. Pulsa "Cargar descomprimida".
6. Selecciona esta carpeta.

## Uso

1. Abre GVA y autentícate normalmente.
2. Abre el Agile Board.
3. Asegúrate de que las tarjetas están cargadas.
4. Pulsa el icono de GVA Planning.
5. Pulsa "Leer tareas de esta pestaña".
6. Comprueba el número de tareas.
7. Puedes descargar el CSV o abrir GVA Planning.

La aplicación de GVA Planning debe leer `location.hash` para recibir los datos.
