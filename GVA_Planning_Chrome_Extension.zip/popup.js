// IMPORTANTE:
// Este archivo no contiene fetch(), XMLHttpRequest, WebSocket ni llamadas a APIs.
// Las tareas se leen ejecutando una función sobre el DOM de la pestaña activa.

const PLANNING_URL = "https://TU_USUARIO.github.io/gva-planning/";

let tasks = [];

const $ = id => document.getElementById(id);
const statusEl = $("status");

function setStatus(text, type="") {
  statusEl.textContent = text;
  statusEl.className = type;
}

function csvEscape(value) {
  return '"' + String(value ?? "").replace(/"/g, '""') + '"';
}

function formatCSVDate(value) {
  if (!value) return "";
  const text = String(value).trim();

  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(text)) {
    const [d,m,y] = text.split("/");
    return `${d.padStart(2,"0")}/${m.padStart(2,"0")}/${y}`;
  }

  const months = {
    gen:0, feb:1, mar:2, abr:3, mai:4, jun:5, jul:6, ago:7,
    set:8, oct:9, nov:10, des:11,
    ene:0, dic:11, jan:0, apr:3, may:4, aug:7, sep:8, dec:11
  };

  const match = text.match(/^(\d{1,2})\s+([A-Za-zÀ-ÿ]+)\s+(\d{4})$/);
  if (match) {
    const d = Number(match[1]);
    const m = months[match[2].slice(0,3).toLowerCase()];
    const y = Number(match[3]);
    if (m !== undefined) {
      return `${String(d).padStart(2,"0")}/${String(m+1).padStart(2,"0")}/${y}`;
    }
  }
  return text;
}

function makeCSV() {
  const headers = [
    "Tasca",
    "Nom",
    "Data real de venciment",
    "Nombre de paraules Salt pro",
    "Persona assignada"
  ];

  const lines = [
    headers.map(csvEscape).join(";"),
    ...tasks.map(t => [
      t.taskId,
      t.name || t.title || "",
      formatCSVDate(t.dueDate),
      t.words || "",
      t.assigned || ""
    ].map(csvEscape).join(";"))
  ];

  return "\ufeff" + lines.join("\r\n");
}

function downloadCSV() {
  const blob = new Blob([makeCSV()], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "tasques_GVA.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({active:true, currentWindow:true});
  return tabs[0];
}

async function readLocalDOM() {
  setStatus("Leyendo únicamente el DOM ya cargado…");

  try {
    const tab = await getActiveTab();

    if (!tab?.url?.startsWith("https://gva.i-mes.net/projects/gva/agile/")) {
      throw new Error("La pestaña activa no es el Agile Board de GVA.");
    }

    // activeTab + scripting: la función se ejecuta en la pestaña activa
    // y solamente consulta document/querySelectorAll.
    const result = await chrome.scripting.executeScript({
      target: {tabId: tab.id},
      func: () => {
        const clean = v => (v || "").replace(/\s+/g, " ").trim();

        function parseWords(value) {
          let s = clean(value).replace(/\u00a0/g, " ").replace(/[^\d.,-]/g, "");
          if (!s) return 0;

          if (s.includes(",") && s.includes(".")) {
            s = s.replace(/\./g, "").replace(",", ".");
          } else if (s.includes(",")) {
            s = s.replace(/,/g, "");
          } else if (s.includes(".") && /^\d+\.\d{3}$/.test(s)) {
            s = s.replace(".", "");
          }

          const n = Number(s);
          return Number.isFinite(n) ? n : 0;
        }

        function field(card, labels) {
          const wanted = labels.map(x => x.toLowerCase());

          for (const b of card.querySelectorAll("b, strong, label")) {
            const label = clean(b.textContent).toLowerCase().replace(/:$/, "");
            if (!wanted.includes(label)) continue;

            let node = b.nextSibling;
            while (node) {
              const t = clean(node.textContent);
              if (t) return t;
              node = node.nextSibling;
            }

            const parent = b.parentElement;
            if (parent) {
              const clone = parent.cloneNode(true);
              clone.querySelectorAll("b, strong, label").forEach(x => x.remove());
              const t = clean(clone.textContent);
              if (t) return t;
            }
          }
          return "";
        }

        function issueId(card) {
          const elements = [
            card.querySelector(".issue-id"),
            card.querySelector("[class*='issue-id']"),
            card.querySelector("a[href*='/issues/']")
          ];

          for (const el of elements) {
            const m = clean(el?.textContent).match(/#(\d+)/);
            if (m) return m[1];

            const href = el?.getAttribute?.("href") || "";
            const hm = href.match(/\/issues\/(\d+)/);
            if (hm) return hm[1];
          }

          const m = clean(card.textContent).match(/#(\d+)/);
          return m ? m[1] : "";
        }

        const cards = Array.from(document.querySelectorAll(".issue-card[data-id]"));
        const seen = new Set();
        const out = [];

        for (const card of cards) {
          const taskId = issueId(card) || card.getAttribute("data-id") || "";
          if (!taskId || seen.has(taskId)) continue;
          seen.add(taskId);

          const titleEl = card.querySelector(
            ".issue-subject, .issue-title, [class*='subject'], a[href*='/issues/']"
          );

          out.push({
            taskId,
            title: clean(titleEl?.textContent),
            name:
              field(card, ["Nom", "Name"]) ||
              clean(card.querySelector(".issue-name, .subject, [class*='subject']")?.textContent),
            dueDate: field(card, [
              "Data real de venciment",
              "Fecha real de vencimiento",
              "Real due date",
              "Due date"
            ]),
            words: parseWords(field(card, [
              "Nombre de paraules Salt pro",
              "Número de palabras Salt pro",
              "Salt pro words",
              "Words"
            ])),
            assigned: field(card, [
              "Persona assignada",
              "Persona asignada",
              "Assigned to",
              "Assignee"
            ]),
            url: card.querySelector("a[href*='/issues/']")?.href || ""
          });
        }

        return out;
      }
    });

    tasks = result?.[0]?.result || [];

    if (!tasks.length) {
      throw new Error("No se encontraron tarjetas .issue-card[data-id] en el DOM cargado.");
    }

    setStatus(`✓ ${tasks.length} tareas encontradas. Lectura 100 % local.`, "ok");
    $("csv").disabled = false;
    $("open").disabled = false;
  } catch (err) {
    console.error(err);
    setStatus("Error: " + err.message, "err");
  }
}

function openPlanning() {
  if (!tasks.length) return;

  // El fragmento #data NO se envía en la petición HTTP al servidor.
  // Solo queda disponible para JavaScript una vez que carga la página.
  const json = JSON.stringify(tasks);
  const payload = btoa(unescape(encodeURIComponent(json)));

  chrome.tabs.create({
    url: PLANNING_URL + "#data=" + encodeURIComponent(payload)
  });
}

$("read").addEventListener("click", readLocalDOM);
$("csv").addEventListener("click", downloadCSV);
$("open").addEventListener("click", openPlanning);
